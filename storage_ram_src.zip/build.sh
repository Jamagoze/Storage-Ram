#!/bin/bash
set -e
NDK=${ANDROID_NDK_LATEST_HOME:-$ANDROID_NDK_HOME}
BIN=$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin
mkdir -p module/bin out
$BIN/aarch64-linux-android30-clang -O2 -o module/bin/xswapd xswapd.c
$BIN/llvm-strip module/bin/xswapd
rm -f out/storage_ram.zip
(cd module && zip -r ../out/storage_ram.zip .)
