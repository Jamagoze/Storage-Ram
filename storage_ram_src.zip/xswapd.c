#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <poll.h>
#include <fcntl.h>
#include <errno.h>
#include <dirent.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/swap.h>
#include <sys/ioctl.h>
#include <sys/uio.h>
#include <linux/loop.h>

#ifndef __NR_pidfd_open
#define __NR_pidfd_open 434
#endif
#ifndef __NR_process_madvise
#define __NR_process_madvise 440
#endif
#ifndef MADV_PAGEOUT
#define MADV_PAGEOUT 21
#endif
#ifndef LOOP_SET_DIRECT_IO
#define LOOP_SET_DIRECT_IO 0x4C08
#endif
#define F2FS_IOC_SET_PIN_FILE _IOW(0xf5, 13, unsigned int)

#define XDIR  "/data/adb/xswap"
#define SWAPF XDIR "/swapfile"
#define LOGF  XDIR "/log.txt"
#define CFG   "/data/adb/modules/storage_ram/config.txt"

static int swap_mb = 2048, psi_thresh = 3, min_avail_mb = 250, min_adj = 900;
static int psi_stall_ms = 60, psi_window_ms = 2000;
static int min_rss_mb = 20, interval = 3, cooldown = 120, max_per_round = 3;
static char skip[1024] = ",";
static FILE *logf_;
static time_t lastout[32768];

static void lg(const char *fmt, ...) {
  if (!logf_) return;
  if (ftell(logf_) > 262144) logf_ = freopen(LOGF, "w", logf_);
  if (!logf_) return;
  va_list a; va_start(a, fmt); vfprintf(logf_, fmt, a); va_end(a);
  fputc('\n', logf_); fflush(logf_);
}

static void load_cfg(void) {
  FILE *f = fopen(CFG, "r"); char l[1100], *e;
  if (!f) return;
  while (fgets(l, sizeof l, f)) {
    if ((e = strchr(l, '\n'))) *e = 0;
    if (l[0] == '#' || !(e = strchr(l, '='))) continue;
    *e++ = 0;
    if (!strcmp(l, "SWAP_MB")) swap_mb = atoi(e);
    else if (!strcmp(l, "PSI_THRESH")) psi_thresh = atoi(e);
    else if (!strcmp(l, "PSI_STALL_MS")) psi_stall_ms = atoi(e);
    else if (!strcmp(l, "PSI_WINDOW_MS")) psi_window_ms = atoi(e);
    else if (!strcmp(l, "MIN_AVAIL_MB")) min_avail_mb = atoi(e);
    else if (!strcmp(l, "MIN_ADJ")) min_adj = atoi(e);
    else if (!strcmp(l, "MIN_RSS_MB")) min_rss_mb = atoi(e);
    else if (!strcmp(l, "INTERVAL")) interval = atoi(e) > 0 ? atoi(e) : 3;
    else if (!strcmp(l, "COOLDOWN")) cooldown = atoi(e);
    else if (!strcmp(l, "MAX_PER_ROUND")) max_per_round = atoi(e) > 0 ? atoi(e) : 3;
    else if (!strcmp(l, "SKIP")) snprintf(skip, sizeof skip, ",%s,", e);
  }
  fclose(f);
}

static void setup_swap(void) {
  struct stat st;
  off_t want = (off_t)swap_mb << 20;
  if (swap_mb <= 0) { lg("swapfile disabled"); return; }
  if (stat(SWAPF, &st) || st.st_size != want) {
    swapoff(SWAPF); unlink(SWAPF);
    int fd = open(SWAPF, O_RDWR | O_CREAT | O_EXCL, 0600);
    if (fd < 0) { lg("create failed: %s", strerror(errno)); return; }
    unsigned int one = 1;
    ioctl(fd, F2FS_IOC_SET_PIN_FILE, &one); /* f2fs swapfiles must be pinned */
    if (fallocate(fd, 0, 0, want)) {
      lg("fallocate failed: %s", strerror(errno)); close(fd); unlink(SWAPF); return;
    }
    fsync(fd); close(fd);
    system("mkswap " SWAPF " >/dev/null 2>&1");
  }
  /* no priority flag: kernel gives it a negative priority, below zram */
  if (swapon(SWAPF, 0) == 0) { lg("swapon direct ok"); return; }
  if (errno == EBUSY) { lg("swap already active"); return; }
  lg("direct swapon failed: %s, trying loop", strerror(errno));

  int lc = open("/dev/loop-control", O_RDWR), n;
  if (lc < 0) { lg("no /dev/loop-control"); return; }
  n = ioctl(lc, LOOP_CTL_GET_FREE); close(lc);
  if (n < 0) { lg("no free loop device"); return; }
  char dev[48];
  snprintf(dev, sizeof dev, "/dev/block/loop%d", n);
  if (access(dev, F_OK)) snprintf(dev, sizeof dev, "/dev/loop%d", n);
  int ld = open(dev, O_RDWR), bf = open(SWAPF, O_RDWR);
  if (ld < 0 || bf < 0 || ioctl(ld, LOOP_SET_FD, bf)) {
    lg("loop attach failed: %s", strerror(errno)); return;
  }
  close(bf);
  if (ioctl(ld, LOOP_SET_DIRECT_IO, 1UL)) { /* without O_DIRECT the loop would double-cache in RAM */
    lg("loop direct io unsupported, no storage swap");
    ioctl(ld, LOOP_CLR_FD, 0); close(ld); return;
  }
  close(ld);
  if (swapon(dev, 0)) lg("loop swapon failed: %s", strerror(errno));
  else lg("swapon via %s ok", dev);
}

static int pressure(void) {
  float a = 0; long avail = 1L << 30; char l[128];
  FILE *f = fopen("/proc/pressure/memory", "r");
  if (f) { if (fscanf(f, "some avg10=%f", &a) != 1) a = 0; fclose(f); }
  f = fopen("/proc/meminfo", "r");
  if (f) {
    while (fgets(l, sizeof l, f)) if (sscanf(l, "MemAvailable: %ld kB", &avail) == 1) break;
    fclose(f);
  }
  return a >= psi_thresh || avail < min_avail_mb * 1024L;
}

static long rd_long(const char *p, long def) {
  long v = def; FILE *f = fopen(p, "r");
  if (f) { if (fscanf(f, "%ld", &v) != 1) v = def; fclose(f); }
  return v;
}

static long ticks(int pid) {
  char p[48], b[1024]; unsigned long u, s;
  snprintf(p, sizeof p, "/proc/%d/stat", pid);
  FILE *f = fopen(p, "r"); if (!f) return -1;
  size_t n = fread(b, 1, sizeof b - 1, f); fclose(f); b[n] = 0;
  char *c = strrchr(b, ')');
  if (!c || sscanf(c + 1, " %*c %*d %*d %*d %*d %*d %*u %*lu %*lu %*lu %*lu %lu %lu", &u, &s) != 2) return -1;
  return (long)(u + s);
}

struct cand { int pid; long adj, rss, t0; char name[96]; };
static struct cand cs[256];

static int skipped(const char *name) {
  char k[300]; snprintf(k, sizeof k, ",%s,", name);
  return strstr(skip, k) != NULL;
}

static int scan(void) {
  DIR *d = opendir("/proc"); struct dirent *e; int n = 0; time_t now = time(NULL);
  if (!d) return 0;
  while ((e = readdir(d)) && n < 256) {
    int pid = atoi(e->d_name); char p[64]; struct stat st;
    if (pid <= 0) continue;
    snprintf(p, sizeof p, "/proc/%d", pid);
    if (stat(p, &st) || st.st_uid < 10000) continue; /* apps only */
    if (now - lastout[pid & 0x7fff] < cooldown) continue;
    snprintf(p, sizeof p, "/proc/%d/oom_score_adj", pid);
    long adj = rd_long(p, 0);
    if (adj < min_adj) continue; /* foreground, visible, audio etc. are all below cached */
    char nm[256] = {0};
    snprintf(p, sizeof p, "/proc/%d/cmdline", pid);
    FILE *f = fopen(p, "r"); if (!f) continue;
    if (!fread(nm, 1, 255, f)) nm[0] = 0;
    fclose(f);
    char *c = strchr(nm, ':'); if (c) *c = 0;
    if (!nm[0] || skipped(nm)) continue;
    long vm = 0, rss = 0;
    snprintf(p, sizeof p, "/proc/%d/statm", pid);
    f = fopen(p, "r"); if (f) { if (fscanf(f, "%ld %ld", &vm, &rss) != 2) rss = 0; fclose(f); }
    if (rss * 4 < (long)min_rss_mb * 1024) continue;
    cs[n].pid = pid; cs[n].adj = adj; cs[n].rss = rss; cs[n].t0 = 0;
    snprintf(cs[n].name, sizeof cs[n].name, "%s", nm);
    n++;
  }
  closedir(d);
  return n;
}

static int cmp(const void *a, const void *b) {
  const struct cand *x = a, *y = b;
  if (x->adj != y->adj) return y->adj > x->adj ? 1 : -1;
  return y->rss > x->rss ? 1 : (y->rss < x->rss ? -1 : 0);
}

static long flush(int pfd, struct iovec *v, int n) {
  long total = 0;
  while (n > 0) {
    long r = syscall(__NR_process_madvise, pfd, v, n, MADV_PAGEOUT, 0);
    if (r <= 0) { v++; n--; continue; } /* range vanished or refused: skip it */
    total += r;
    while (r > 0 && n > 0) {
      if ((size_t)r >= v->iov_len) { r -= v->iov_len; v++; n--; }
      else { v->iov_base = (char *)v->iov_base + r; v->iov_len -= r; r = 0; }
    }
  }
  return total;
}

/* page out private anonymous memory only (java heap, malloc, anon mmaps) */
static long pageout(int pid) {
  static struct iovec iov[1024];
  char p[48], line[512]; int n = 0; long total = 0;
  int pfd = syscall(__NR_pidfd_open, pid, 0);
  if (pfd < 0) return -1;
  snprintf(p, sizeof p, "/proc/%d/maps", pid);
  FILE *f = fopen(p, "r");
  if (!f) { close(pfd); return -1; }
  while (fgets(line, sizeof line, f)) {
    unsigned long s, e, off, ino; char perm[8], dev[16]; int nc = 0;
    if (sscanf(line, "%lx-%lx %7s %lx %15s %lu %n", &s, &e, perm, &off, dev, &ino, &nc) < 6) continue;
    if (perm[0] != 'r' || perm[1] != 'w' || perm[3] != 'p' || ino) continue;
    const char *nm = line + nc;
    if (*nm == '/') continue;
    if (*nm == '[' && strncmp(nm, "[anon", 5) && strncmp(nm, "[heap]", 6)) continue;
    iov[n].iov_base = (void *)s; iov[n].iov_len = e - s; n++;
    if (n == 1024) { total += flush(pfd, iov, n); n = 0; }
  }
  fclose(f);
  if (n) total += flush(pfd, iov, n);
  close(pfd);
  return total;
}

static int round_(void) {
  int n = scan(), lim, i, paged = 0;
  if (!n) return 0;
  qsort(cs, n, sizeof cs[0], cmp);
  lim = n < 24 ? n : 24;
  for (i = 0; i < lim; i++) cs[i].t0 = ticks(cs[i].pid);
  sleep(2); /* idle = no CPU use during this window */
  for (i = 0; i < lim && paged < max_per_round; i++) {
    long t1 = ticks(cs[i].pid);
    if (t1 < 0 || cs[i].t0 < 0 || t1 - cs[i].t0 > 2) continue;
    long b = pageout(cs[i].pid);
    lastout[cs[i].pid & 0x7fff] = time(NULL);
    if (b >= 0) { paged++; lg("pageout %s pid=%d adj=%ld %ldMB", cs[i].name, cs[i].pid, cs[i].adj, b >> 20); }
  }
  return paged;
}

static int psi_fd = -1;

/* kernel wakes us only when memory stall passes the threshold: no polling timer */
static void psi_init(void) {
  char b[64];
  psi_fd = open("/proc/pressure/memory", O_RDWR | O_NONBLOCK);
  if (psi_fd < 0) return;
  snprintf(b, sizeof b, "some %d %d", psi_stall_ms * 1000, psi_window_ms * 1000);
  if (write(psi_fd, b, strlen(b) + 1) < 0) { close(psi_fd); psi_fd = -1; }
  lg(psi_fd >= 0 ? "psi trigger armed" : "psi trigger failed, polling");
}

int main(void) {
  nice(10);
  FILE *f = fopen("/proc/self/oom_score_adj", "w");
  if (f) { fputs("-1000", f); fclose(f); }
  mkdir(XDIR, 0700);
  logf_ = fopen(LOGF, "a");
  load_cfg();
  setup_swap();
  psi_init();
  for (;;) {
    if (psi_fd >= 0) {
      struct pollfd p = { psi_fd, POLLPRI, 0 };
      if (poll(&p, 1, -1) < 0) continue;
      if (p.revents & POLLERR) { close(psi_fd); psi_fd = -1; continue; }
      if (!(p.revents & POLLPRI)) continue;
    } else {
      sleep(interval);
      if (!pressure()) continue;
    }
    if (!round_()) sleep(10); /* nothing left to page out: back off */
  }
}
