[ "$ARCH" = arm64 ] || abort "arm64 only"
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/bin/xswapd 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
