#!/system/bin/sh
pkill -x xswapd
swapoff /data/adb/xswap/swapfile
rm -rf /data/adb/xswap
