#!/system/bin/sh
MODDIR=${0%/*}
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 5; done
sleep 20
pkill -x xswapd 2>/dev/null
nohup "$MODDIR/bin/xswapd" >/dev/null 2>&1 &
